# 🥃 Rectification Controller

> Автоматизированная система управления ректификационной колонной на базе ESP32

[![Platform](https://img.shields.io/badge/platform-ESP32-blue.svg)](https://www.espressif.com/en/products/socs/esp32)
[![Framework](https://img.shields.io/badge/framework-Arduino-00979D.svg)](https://www.arduino.cc/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Version](https://img.shields.io/badge/version-1.2-orange.svg)](https://github.com/grifmax/rectification-controller)
[![MQTT](https://img.shields.io/badge/MQTT-supported-green.svg)](docs/API.md#mqtt-integration)
[![Home Assistant](https://img.shields.io/badge/Home%20Assistant-ready-blue.svg)](docs/HOME_ASSISTANT.md)

## 📋 Описание

Полнофункциональная система автоматического управления процессами ректификации и дистилляции с веб-интерфейсом, множественными датчиками температуры, автоматическим управлением мощностью и развитой системой безопасности.

### 🆕 Что нового в v1.2

- 🏠 **Home Assistant Integration** - автоматическое обнаружение через MQTT Discovery
- 📡 **MQTT Client** - публикация состояния и метрик в реальном времени
- 🔒 **HTTP Basic Authentication** - защита веб-интерфейса и API
- 🚫 **Rate Limiting** - защита от DDoS атак (60 req/min на IP)
- 🛡️ **Security Headers** - CSP, X-Frame-Options, и другие заголовки безопасности
- ⚡ **PZEM-004T Support** - точный мониторинг напряжения, тока, мощности и энергии
- 📊 **Energy Tracking** - интеграция с Energy Dashboard в Home Assistant

👉 **[Полная документация API](docs/API.md)** | **[Интеграция с Home Assistant](docs/HOME_ASSISTANT.md)**

### ✨ Основные возможности

- 🌡️ **Мониторинг температуры** - до 5 датчиков DS18B20
- 🔥 **Управление нагревом** - ручной/автоматический режим с ПИ-регулятором
- ⚡ **Контроль мощности** - до 5000 Вт с PZEM-004T мониторингом
- 💧 **Автоматический отбор** - насос с программируемой скоростью
- 🌐 **Веб-интерфейс** - полное управление через браузер
- 📊 **Графики в реальном времени** - отслеживание всех параметров
- 🛡️ **Многоуровневая система безопасности** - 10 типов проверок + Rate Limiting
- 📡 **MQTT & Home Assistant** - автоматическая интеграция с умным домом
- 🔒 **Безопасность** - HTTP Basic Auth, Security Headers, защита от DDoS
- 📱 **PWA** - работает как мобильное приложение
- 🔔 **Звуковые оповещения** - о смене фаз и ошибках
- 💾 **Сохранение настроек** - в энергонезависимую память

## 🎯 Поддерживаемые процессы

### Ректификация (8 фаз)
1. Нагрев до кипения
2. Стабилизация колонны
3. Отбор голов
4. Повторная стабилизация
5. Отбор тела (основной продукт)
6. Отбор хвостов
7. Завершение

**Две модели работы:**
- **Классическая** - отбор по заданным объемам
- **Альтернативная** - отбор по времени и скорости

### Дистилляция (5 фаз)
1. Нагрев
2. Отбор голов (опционально)
3. Основная дистилляция
4. Завершение

## 🛠️ Оборудование

### Обязательные компоненты:
- **ESP32 DevKit** (любая версия)
- **Датчики DS18B20** (минимум 2 шт.)
- **SSR/реле для нагревателя** (до 5 кВт)
- **Реле для насоса** (12В/24В)
- **Реле для клапана** (опционально)

### Опциональные компоненты:
- **OLED дисплей** 128x64 (SSD1306, I2C)
- **4 кнопки** управления
- **Пьезоизлучатель** для звуковых сигналов
- **PZEM-004T** для точного измерения мощности

## 🚀 Быстрый старт

### 1. Установка

```bash
# Клонирование репозитория
git clone https://github.com/grifmax/rectification-controller.git
cd rectification-controller

# Установка зависимостей через PlatformIO
pio lib install

# Компиляция
pio run

# Загрузка на ESP32
pio run --target upload

# Загрузка веб-интерфейса
pio run --target uploadfs
```

### 2. Первое подключение

1. ESP32 создаст WiFi точку доступа **"Distiller_XXXX"**
2. Пароль по умолчанию: **"distiller12345"**
3. Подключитесь к точке доступа
4. Откройте браузер: **http://192.168.4.1**
5. Настройте систему через веб-интерфейс

### 3. Подключение датчиков

```
DS18B20 (OneWire) → GPIO 4
Нагреватель       → GPIO 32
Насос             → GPIO 33
Клапан            → GPIO 25
Кнопки            → GPIO 13, 14, 27, 12
OLED (I2C)        → GPIO 21 (SDA), 22 (SCL)
```

## 📡 API

### REST Endpoints

```http
# Статус системы
GET /api/status

# Управление нагревателем
POST /api/heater
{
  "power": 2000,  // Вт
  "mode": "manual" // или "auto"
}

# Запуск ректификации
POST /api/rectification/start
{
  "model": "classic",
  "headsVolume": 50,
  "bodyVolume": 2000
}

# Остановка процесса
POST /api/rectification/stop
```

### WebSocket

```javascript
// Подключение
const ws = new WebSocket('ws://192.168.4.1/ws');

// Автоматические обновления каждую секунду
ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('Температура куба:', data.temperatures.cube);
};
```

## 🔐 Система безопасности

### Автоматические проверки:
- ✅ Подключение датчиков
- ✅ Превышение максимальной температуры (105°C)
- ✅ Скорость роста температуры (>5°C/мин)
- ✅ Температура воды охлаждения
- ✅ Максимальное время работы (12 часов)
- ✅ Watchdog Timer (30 секунд)

### При обнаружении проблемы:
- ⚠️ Автоматическое отключение нагревателя
- ⚠️ Остановка насоса
- ⚠️ Закрытие клапана
- ⚠️ Звуковое оповещение
- ⚠️ Логирование в Serial и файл

## 📊 Веб-интерфейс

![Web Interface](docs/screenshots/interface.png)

**Возможности:**
- 📈 Графики температур в реальном времени
- 🎛️ Управление всеми параметрами
- 📊 Отслеживание процесса
- ⚙️ Настройка системы
- 📱 Адаптивный дизайн для мобильных
- 🌙 Темная тема

## 🧪 Тестирование

```cpp
// Запуск тестов безопасности
#define RUN_SAFETY_TESTS
runAllSafetyTests();
```

Доступные тесты:
- ✓ Инициализация системы
- ✓ Превышение температуры
- ✓ Отключение датчиков
- ✓ Скорость роста температуры
- ✓ Превышение времени работы
- ✓ Аварийное отключение

## 📝 Serial команды

```bash
start rect  # Запуск ректификации
start dist  # Запуск дистилляции
stop        # Остановка
pause       # Пауза
resume      # Возобновление
power 75    # Установка мощности 75%
temps       # Показать температуры
scan        # Сканировать датчики
settings    # Показать настройки
help        # Справка
```

## 📚 Документация

### Руководства

- **[API Documentation](docs/API.md)** - Полная документация REST API, WebSocket и MQTT
  - REST API endpoints
  - WebSocket протокол
  - MQTT топики и сообщения
  - Home Assistant MQTT Discovery
  - Примеры использования на Python, Node.js, cURL

- **[Home Assistant Integration](docs/HOME_ASSISTANT.md)** - Пошаговое руководство по интеграции
  - Настройка MQTT брокера (Mosquitto)
  - Автоматическое обнаружение устройства
  - Примеры Dashboard карточек
  - Автоматизации и уведомления
  - Интеграция с Energy Dashboard
  - Troubleshooting

- **[Technical Specification](SPEC.md)** - Техническая спецификация v1.2
  - Архитектура системы
  - Описание режимов работы
  - BOM (Bill of Materials)
  - Распиновка ESP32-S3
  - Формулы и алгоритмы

### Быстрые ссылки

| Тема | Документ | Описание |
|------|----------|----------|
| REST API | [API.md](docs/API.md#rest-api) | HTTP endpoints для управления |
| MQTT | [API.md](docs/API.md#mqtt-integration) | MQTT топики и полезная нагрузка |
| Home Assistant | [HOME_ASSISTANT.md](docs/HOME_ASSISTANT.md) | Полное руководство по интеграции |
| Безопасность | [API.md](docs/API.md#authentication) | Authentication & Rate Limiting |
| Energy Tracking | [HOME_ASSISTANT.md](docs/HOME_ASSISTANT.md#energy-dashboard) | Отслеживание энергопотребления |
| Примеры кода | [API.md](docs/API.md#examples) | Python, Node.js примеры |

## 🗂️ Структура проекта

```
rectification-controller/
├── src/
│   ├── main.cpp              # Главный файл
│   ├── config.h              # Конфигурация
│   ├── rectification.cpp/h   # Процесс ректификации
│   ├── distillation.cpp/h    # Процесс дистилляции
│   ├── heater.cpp/h          # Управление нагревом
│   ├── pump.cpp/h            # Управление насосом
│   ├── temp_sensors.cpp/h    # Датчики температуры
│   ├── safety.cpp/h          # Система безопасности
│   ├── emergency.cpp/h       # Аварийное восстановление
│   ├── watchdog.cpp/h        # Защита от зависаний
│   ├── settings.cpp/h        # Управление настройками
│   ├── web.cpp/h             # Веб-сервер и API
│   ├── display.cpp/h         # OLED дисплей
│   └── data/                 # Веб-интерфейс
│       ├── index.html
│       ├── styles.css
│       └── js/main.js
├── test/
│   └── test_safety.cpp       # Тесты безопасности
├── platformio.ini            # Конфигурация PlatformIO
├── .gitignore
└── README.md
```

## ⚙️ Конфигурация

Основные настройки в `src/config.h`:

```cpp
// WiFi
#define WIFI_SSID "DistillerAP"
#define WIFI_PASSWORD "distiller12345"

// Безопасность
#define MAX_CUBE_TEMP 105.0        // °C
#define MAX_TEMP_RISE_RATE 5.0     // °C/мин
#define MAX_RUNTIME_HOURS 12.0     // часов
#define WATCHDOG_TIMEOUT 30        // секунд

// Мощность
#define MAX_HEATER_POWER 3000      // Вт
```

## 📈 Производительность

- **Частота обновления температур:** 1 сек
- **Частота проверки безопасности:** 500 мс
- **Частота обновления веб-интерфейса:** 1 сек
- **Watchdog таймаут:** 30 сек
- **Используемая память:** ~220 KB из 520 KB
- **Размер прошивки:** ~500 KB из 4 MB

## 🤝 Вклад в проект

Буду рад вашим предложениям и улучшениям! 

1. Fork репозитория
2. Создайте ветку для ваших изменений
3. Commit ваших изменений
4. Push в ветку
5. Создайте Pull Request

## 📄 Лицензия

MIT License - см. файл [LICENSE](LICENSE)

## ⚠️ Предупреждение

**ВАЖНО:** Эта система предназначена для автоматизации процесса ректификации в домашних условиях. Всегда:

- 🔥 Соблюдайте правила пожарной безопасности
- 👁️ Не оставляйте работающую систему без присмотра
- 📏 Используйте только разрешенное оборудование
- ⚡ Соблюдайте правила электробезопасности
- 📖 Убедитесь, что производство разрешено в вашей стране

## 📞 Поддержка

- 💬 GitHub Issues для вопросов и багов
- 📧 Email: [ваш email]
- 💭 Обсуждения в Discussions

## 🙏 Благодарности

- PlatformIO за отличную платформу разработки
- Espressif за ESP32
- Сообществу Arduino за библиотеки и помощь

---

**Сделано с ❤️ для энтузиастов дистилляции**

⭐ Если проект полезен, поставьте звезду на GitHub!
